import 'package:audioplayers/audioplayers.dart';
import '../constants/assets.dart';

class AudioService {
  static final AudioPlayer _player = AudioPlayer();
  
  static Future<void> playCorrectSound() async {
    await _playSound(AppAssets.correctSound);
  }
  
  static Future<void> playWrongSound() async {
    await _playSound(AppAssets.wrongSound);
  }
  
  static Future<void> playFlipSound() async {
    await _playSound(AppAssets.flipSound);
  }
  
  static Future<void> playCompleteSound() async {
    await _playSound(AppAssets.completeSound);
  }
  
  static Future<void> _playSound(String soundPath) async {
    try {
      await _player.play(AssetSource(soundPath));
    } catch (e) {
      print('Error playing sound: $e');
    }
  }
  
  static void dispose() {
    _player.dispose();
  }
}