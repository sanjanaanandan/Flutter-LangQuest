import 'package:flutter/material.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int _currentQuestionIndex = 0;
  int _score = 0;
  String? _selectedAnswer;
  bool _answered = false;

  final List<Map<String, dynamic>> _questions = [
    {
      'question': "How do you say 'Hello' in Spanish?",
      'options': ["Hola", "Bonjour", "Ciao", "Hallo"],
      'correctAnswer': "Hola",
      'explanation': "Hola is Spanish for Hello"
    },
    {
      'question': "What does 'Gracias' mean in English?",
      'options': ["Hello", "Goodbye", "Thank you", "Please"],
      'correctAnswer': "Thank you",
      'explanation': "Gracias means Thank you in Spanish"
    },
    {
      'question': "How do you say 'Goodbye' in Spanish?",
      'options': ["Hola", "Por favor", "Adiós", "Sí"],
      'correctAnswer': "Adiós",
      'explanation': "Adiós is Spanish for Goodbye"
    },
    {
      'question': "What does 'Por favor' mean?",
      'options': ["Thank you", "Please", "You're welcome", "Excuse me"],
      'correctAnswer': "Please",
      'explanation': "Por favor means Please in Spanish"
    },
  ];

  void _handleAnswer(String answer) {
    setState(() {
      _selectedAnswer = answer;
      _answered = true;
      if (answer == _questions[_currentQuestionIndex]['correctAnswer']) {
        _score++;
      }
    });
  }

  void _nextQuestion() {
    if (_currentQuestionIndex < _questions.length - 1) {
      setState(() {
        _currentQuestionIndex++;
        _selectedAnswer = null;
        _answered = false;
      });
    } else {
      _showResults();
    }
  }

  void _showResults() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Quiz Completed! 🎉'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Your Score:'),
            const SizedBox(height: 10),
            Text(
              '$_score / ${_questions.length}',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.blue),
            ),
            const SizedBox(height: 10),
            Text(
              '${(_score / _questions.length * 100).toStringAsFixed(0)}%',
              style: const TextStyle(fontSize: 18, color: Colors.green),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Close dialog
              Navigator.pop(context); // Go back to home
            },
            child: const Text('Finish'),
          ),
        ],
      ),
    );
  }

  void _resetQuiz() {
    setState(() {
      _currentQuestionIndex = 0;
      _score = 0;
      _selectedAnswer = null;
      _answered = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final currentQuestion = _questions[_currentQuestionIndex];
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quiz'),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _resetQuiz,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Progress indicator
            LinearProgressIndicator(
              value: (_currentQuestionIndex + 1) / _questions.length,
              backgroundColor: Colors.grey[300],
              valueColor: const AlwaysStoppedAnimation<Color>(Colors.green),
            ),
            
            const SizedBox(height: 20),
            
            // Question counter
            Text(
              'Question ${_currentQuestionIndex + 1} of ${_questions.length}',
              style: TextStyle(fontSize: 16, color: Colors.grey[600]),
            ),
            
            const SizedBox(height: 20),
            
            // Question
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 5,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
                currentQuestion['question'],
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            
            const SizedBox(height: 30),
            
            // Options
            Expanded(
              child: ListView(
                children: (currentQuestion['options'] as List<String>).map((option) {
                  bool isCorrect = option == currentQuestion['correctAnswer'];
                  bool isSelected = option == _selectedAnswer;
                  
                  Color buttonColor = Colors.blue;
                  if (_answered) {
                    if (isCorrect) {
                      buttonColor = Colors.green;
                    } else if (isSelected) {
                      buttonColor = Colors.red;
                    } else {
                      buttonColor = Colors.grey;
                    }
                  }
                  
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: ElevatedButton(
                      onPressed: _answered ? null : () => _handleAnswer(option),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: buttonColor,
                        foregroundColor: Colors.white,
                        minimumSize: const Size(double.infinity, 50),
                      ),
                      child: Text(option),
                    ),
                  );
                }).toList(),
              ),
            ),
            
            // Explanation and Next Button
            if (_answered) ...[
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.blue),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Explanation:',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(currentQuestion['explanation']),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _nextQuestion,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 50),
                ),
                child: Text(
                  _currentQuestionIndex < _questions.length - 1 
                      ? 'Next Question' 
                      : 'Finish Quiz'
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}