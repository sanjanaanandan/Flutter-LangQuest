import 'package:flutter/material.dart';

class FlashcardsScreen extends StatefulWidget {
  const FlashcardsScreen({super.key});

  @override
  _FlashcardsScreenState createState() => _FlashcardsScreenState();
}

class _FlashcardsScreenState extends State<FlashcardsScreen> {
  int cardIndex = 0;
  bool showFront = true;

  List<Map<String, String>> cards = [
    {'front': 'Hello', 'back': 'Hola'},
    {'front': 'Goodbye', 'back': 'Adiós'},
    {'front': 'Thank you', 'back': 'Gracias'},
  ];

  void flipCard() {
    setState(() {
      showFront = !showFront;
    });
  }

  void nextCard() {
    setState(() {
      cardIndex = (cardIndex + 1) % cards.length;
      showFront = true;
    });
  }

  void prevCard() {
    setState(() {
      cardIndex = (cardIndex - 1) % cards.length;
      showFront = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flashcards'),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Card ${cardIndex + 1} of ${cards.length}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: flipCard,
              child: Container(
                width: 300,
                height: 200,
                decoration: BoxDecoration(
                  color: showFront ? Colors.blue : Colors.green,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Center(
                  child: Text(
                    showFront ? cards[cardIndex]['front']! : cards[cardIndex]['back']!,
                    style: const TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Tap the card to flip',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: prevCard,
                  child: const Text('Previous'),
                ),
                const SizedBox(width: 20),
                ElevatedButton(
                  onPressed: nextCard,
                  child: const Text('Next'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}