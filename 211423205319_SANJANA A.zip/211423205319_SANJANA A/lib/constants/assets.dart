class AppAssets {
  // Images
  static const String logo = 'assets/images/logo.png';
  static const String welcome = 'assets/images/welcome.png';
  static const String success = 'assets/images/success.png';
  static const String emptyState = 'assets/images/empty_state.png';
  
  // Sounds
  static const String correctSound = 'assets/sounds/correct.mp3';
  static const String wrongSound = 'assets/sounds/wrong.mp3';
  static const String flipSound = 'assets/sounds/flip.mp3';
  static const String completeSound = 'assets/sounds/complete.mp3';
}