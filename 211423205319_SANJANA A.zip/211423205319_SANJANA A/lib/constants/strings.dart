class AppStrings {
  static const String appName = 'Language Learn';
  static const String slogan = 'Master Languages Faster';
  
  // Home Screen
  static const String welcome = 'Welcome Back!';
  static const String dailyGoal = 'Daily Goal';
  static const String streak = 'Day Streak';
  
  // Features
  static const String flashcards = 'Flashcards';
  static const String quiz = 'Quiz Challenge';
  static const String progress = 'My Progress';
  static const String profile = 'Profile';
  
  // Descriptions
  static const String flashcardsDesc = 'Learn with interactive cards';
  static const String quizDesc = 'Test your knowledge';
  static const String progressDesc = 'Track your learning journey';
  static const String profileDesc = 'Manage your account';
}