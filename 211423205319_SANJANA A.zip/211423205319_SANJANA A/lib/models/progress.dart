import 'package:flutter/material.dart';

class QuizResult {
  final String id;
  final int score;
  final int totalQuestions;
  final DateTime date;
  final String quizType;
  final int timeSpent;

  QuizResult({
    required this.id,
    required this.score,
    required this.totalQuestions,
    required this.date,
    this.quizType = 'General',
    this.timeSpent = 0,
  });

  double get percentage => (score / totalQuestions) * 100;
}

class ProgressModel with ChangeNotifier {
  List<QuizResult> _quizHistory = [];
  int _streak = 0;
  int _totalWordsLearned = 0;
  int _dailyGoal = 10;
  
  List<QuizResult> get quizHistory => _quizHistory;
  int get streak => _streak;
  int get totalWordsLearned => _totalWordsLearned;
  int get dailyGoal => _dailyGoal;
  
  double get overallProgress {
    if (_quizHistory.isEmpty) return 0.0;
    final totalScore = _quizHistory.fold(0, (sum, result) => sum + result.score);
    final totalQuestions = _quizHistory.fold(0, (sum, result) => sum + result.totalQuestions);
    return totalQuestions > 0 ? (totalScore / totalQuestions) * 100 : 0.0;
  }
  
  void addQuizResult(QuizResult result) {
    _quizHistory.add(result);
    
    final today = DateTime.now();
    final lastQuizDate = _quizHistory.isNotEmpty ? _quizHistory.last.date : null;
    
    if (lastQuizDate != null && _isConsecutiveDay(lastQuizDate, today)) {
      _streak++;
    } else {
      _streak = 1;
    }
    
    notifyListeners();
  }
  
  void updateDailyGoal(int newGoal) {
    _dailyGoal = newGoal;
    notifyListeners();
  }
  
  void incrementWordsLearned() {
    _totalWordsLearned++;
    notifyListeners();
  }
  
  bool _isConsecutiveDay(DateTime previous, DateTime current) {
    return current.difference(previous).inDays == 1;
  }
  
  void loadSampleData() {
    _quizHistory = [
      QuizResult(
        id: '1',
        score: 8,
        totalQuestions: 10,
        date: DateTime.now().subtract(const Duration(days: 1)),
        quizType: 'Vocabulary',
        timeSpent: 300,
      ),
      QuizResult(
        id: '2',
        score: 6,
        totalQuestions: 8,
        date: DateTime.now().subtract(const Duration(days: 2)),
        quizType: 'Grammar',
        timeSpent: 420,
      ),
    ];
    _streak = 3;
    _totalWordsLearned = 25;
    notifyListeners();
  }
}