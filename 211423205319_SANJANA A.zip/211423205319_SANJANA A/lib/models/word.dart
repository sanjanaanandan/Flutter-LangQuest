import 'package:flutter/material.dart';

class Word {
  final String id;
  final String front;
  final String back;
  final String language;
  final String category;
  final bool learned;
  final int reviewCount;
  final DateTime lastReviewed;

  Word({
    required this.id,
    required this.front,
    required this.back,
    required this.language,
    this.category = 'General',
    this.learned = false,
    this.reviewCount = 0,
    required this.lastReviewed,
  });

  Word copyWith({
    String? front,
    String? back,
    String? language,
    String? category,
    bool? learned,
    int? reviewCount,
    DateTime? lastReviewed,
  }) {
    return Word(
      id: id,
      front: front ?? this.front,
      back: back ?? this.back,
      language: language ?? this.language,
      category: category ?? this.category,
      learned: learned ?? this.learned,
      reviewCount: reviewCount ?? this.reviewCount,
      lastReviewed: lastReviewed ?? this.lastReviewed,
    );
  }
}

class WordModel with ChangeNotifier {
  List<Word> _words = [];
  
  List<Word> get words => _words;
  List<Word> get learnedWords => _words.where((word) => word.learned).toList();
  List<Word> get dueForReview => _words.where((word) => 
      DateTime.now().difference(word.lastReviewed).inDays >= 1).toList();
  
  void addWord(Word word) {
    _words.add(word);
    notifyListeners();
  }
  
  void markAsLearned(String wordId) {
    final index = _words.indexWhere((word) => word.id == wordId);
    if (index != -1) {
      _words[index] = _words[index].copyWith(learned: true);
      notifyListeners();
    }
  }
  
  void loadSampleWords() {
    _words = [
      Word(
        id: '1',
        front: 'Hello',
        back: 'Hola',
        language: 'Spanish',
        category: 'Greetings',
        lastReviewed: DateTime.now(),
      ),
      Word(
        id: '2',
        front: 'Goodbye',
        back: 'Adiós',
        language: 'Spanish',
        category: 'Greetings',
        lastReviewed: DateTime.now(),
      ),
      Word(
        id: '3',
        front: 'Thank you',
        back: 'Gracias',
        language: 'Spanish',
        category: 'Greetings',
        lastReviewed: DateTime.now(),
      ),
      Word(
        id: '4',
        front: 'Please',
        back: 'Por favor',
        language: 'Spanish',
        category: 'Greetings',
        lastReviewed: DateTime.now(),
      ),
      Word(
        id: '5',
        front: 'Yes',
        back: 'Sí',
        language: 'Spanish',
        category: 'Basics',
        lastReviewed: DateTime.now(),
      ),
    ];
    notifyListeners();
  }
}